/**
 *  Copyright 2011 Waqar Malik <waqarmalik@gmail.com>
 *  Copyright 2011 SESO Group at NASA Ames
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

#ifndef ROUTEGEN_HPP
#define ROUTEGEN_HPP

#include <iostream>
#include <limits>
#include <vector>
#include <list>
#include <memory>
#include "network.hpp"

class routeGen {
public:
    routeGen(std::shared_ptr<network>, std::string);
    std::vector<int> getRoute(int from, int to, std::list<int> viaNodes);
    bool getShortestPath(int from, int to, std::vector<int>& path);
    
private:
    std::vector<std::vector<double> > graph; // Original Node-link model graph:
    std::vector<std::vector<short> > pred; // a predecessor matrix to construct the path

    void FloydWarshall(); // all pairs shortest path

    void getPath(int from, int to, std::vector<int>& path);

    std::shared_ptr<network> net;
    const int INF;
};

#endif // ROUTEGEN_HPP
